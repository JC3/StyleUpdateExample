data.raw["gui-style"].default["example-style"] = {
	type = "button_style",
	parent = "button_style"
}
