data.raw["gui-style"].default["example-style"] = {
	type = "checkbox_style",	-- was button_style in 1.0.0
	parent = "checkbox_style"	-- was button_style in 1.0.0
}
